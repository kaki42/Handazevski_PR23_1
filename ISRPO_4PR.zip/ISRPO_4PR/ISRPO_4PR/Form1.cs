﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ISRPO_4PR
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            comboBoxShift.SelectedIndex = 2;
            comboBoxLanguage.SelectedIndex = 0;
        }

        private bool ValidateInput()
        {
            if (string.IsNullOrWhiteSpace(textBoxInput.Text))
            {
                MessageBox.Show("Введите текст!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            // Дополнительная проверка на выбор сдвига
            if (comboBoxShift.SelectedItem == null)
            {
                MessageBox.Show("Выберите величину сдвига!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            return true;
        }

        private string ProcessText(string text, int shift)
        {
            string alphabet = comboBoxLanguage.SelectedItem.ToString() == "Русский"
                ? "абвгдеёжзийклмнопрстуфхцчшщъыьэюя"
                : "abcdefghijklmnopqrstuvwxyz";

            StringBuilder result = new StringBuilder();

            foreach (char c in text)
            {
                if (!char.IsLetter(c))
                {
                    result.Append(c);
                    continue;
                }

                bool isUpper = char.IsUpper(c);
                int index = alphabet.IndexOf(char.ToLower(c));

                if (index < 0)
                {
                    result.Append(c);
                    continue;
                }

                int newIndex = (index + shift) % alphabet.Length;
                if (newIndex < 0) newIndex += alphabet.Length;

                char newChar = alphabet[newIndex];
                result.Append(isUpper ? char.ToUpper(newChar) : newChar);
            }

            return result.ToString();
        }

        private void buttonDecrypt_Click_1(object sender, EventArgs e)
        {
            if (ValidateInput())
            {
                //  получение значения сдвига
                int shift = Convert.ToInt32(comboBoxShift.SelectedItem);
                textBoxOutput.Text = ProcessText(textBoxInput.Text, -shift);
            }
        }

        private void buttonEncrypt_Click_1(object sender, EventArgs e)
        {
            if (ValidateInput())
            {
                // получение значения сдвига
                int shift = Convert.ToInt32(comboBoxShift.SelectedItem);
                textBoxOutput.Text = ProcessText(textBoxInput.Text, shift);
            }
        }

        private void buttonClear_Click_1(object sender, EventArgs e)
        {
            textBoxInput.Clear();
            textBoxOutput.Clear();
        }
    }
}
